		<div id="board">
			<div class="page">
			<div id="ui-global-0">
				<div class="tiles tilemenu azure-left">
					<?php echo $TILES_0; ?>
				</div>
				<div class="listmenu azure-right">
					<?php echo $TILES_1; ?>
				</div>
				<div id="main-container" class="bands container azure-center">
					<?php echo $HTML; ?>
				</div>
				<div class="clearfloat"></div>
			</div>
			</div>
		</div>
		