<?php 
	date_default_timezone_set('Asia/Kolkata');
	echo date("s i H d n Y"); 
	exit;
?>
