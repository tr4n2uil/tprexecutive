-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 11, 2011 at 04:36 AM
-- Server version: 5.1.52
-- PHP Version: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `executive`
--

-- --------------------------------------------------------

--
-- Table structure for table `chains`
--

CREATE TABLE IF NOT EXISTS `chains` (
  `chainid` bigint(20) NOT NULL AUTO_INCREMENT,
  `masterkey` bigint(20) NOT NULL,
  `level` int(10) NOT NULL DEFAULT '0',
  `authorize` varchar(255) NOT NULL DEFAULT 'edit:add:remove:list',
  `root` varchar(255) NOT NULL,
  `links` bigint(20) NOT NULL DEFAULT '0',
  `reads` bigint(20) NOT NULL DEFAULT '0',
  `writes` bigint(20) NOT NULL DEFAULT '0',
  `ctime` datetime NOT NULL,
  `rtime` datetime NOT NULL,
  `wtime` datetime NOT NULL,
  PRIMARY KEY (`chainid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `chains`
--

INSERT INTO `chains` (`chainid`, `masterkey`, `level`, `authorize`, `root`, `links`, `reads`, `writes`, `ctime`, `rtime`, `wtime`) VALUES
(0, 5, 0, 'edit:add:remove:list', '/5', 0, 0, 0, '2011-08-11 04:19:29', '2011-08-11 04:19:29', '2011-08-11 04:19:29'),
(1, 5, 0, 'edit:list', '/5', 0, 0, 0, '2011-08-11 04:20:46', '2011-08-11 04:20:46', '2011-08-11 04:20:46'),
(2, 5, 0, 'edit:add:remove', '/5', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 5, 0, 'edit', '/5', 0, 0, 0, '2011-08-10 11:15:11', '2011-08-10 11:15:11', '2011-08-10 11:15:12'),
(4, 5, 0, 'edit:add:remove', '/5', 0, 0, 0, '2011-08-10 12:42:56', '2011-08-10 12:42:57', '2011-08-10 12:42:57'),
(5, 5, 0, 'edit:add:remove:list', '/5', 0, 2, 0, '0000-00-00 00:00:00', '2011-08-10 17:12:07', '0000-00-00 00:00:00'),
(8, 5, 1, 'edit:add:remove:list', '/5', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 5, 1, 'edit:add:remove:list', '/5', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 5, 0, 'edit:add:remove', '/5', 0, 0, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `companies`
--

CREATE TABLE IF NOT EXISTS `companies` (
  `comid` bigint(20) NOT NULL,
  `owner` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `site` varchar(255) NOT NULL,
  `interests` text NOT NULL,
  `photo` bigint(20) NOT NULL,
  PRIMARY KEY (`comid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companies`
--


-- --------------------------------------------------------

--
-- Table structure for table `contents`
--

CREATE TABLE IF NOT EXISTS `contents` (
  `cntid` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner` bigint(20) NOT NULL,
  `cntname` varchar(255) NOT NULL,
  `cntstype` int(11) NOT NULL DEFAULT '0',
  `cntstyle` varchar(255) NOT NULL DEFAULT '',
  `cntttype` int(11) NOT NULL,
  `cnttpl` varchar(255) NOT NULL,
  `cntdtype` int(11) NOT NULL,
  `cntdata` text NOT NULL,
  PRIMARY KEY (`cntid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `contents`
--


-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE IF NOT EXISTS `events` (
  `eventid` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `rejection` text NOT NULL,
  `home` bigint(20) NOT NULL,
  PRIMARY KEY (`eventid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--


-- --------------------------------------------------------

--
-- Table structure for table `keys`
--

CREATE TABLE IF NOT EXISTS `keys` (
  `keyid` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `keyvalue` varchar(255) NOT NULL,
  PRIMARY KEY (`keyid`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `keyvalue` (`keyvalue`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `keys`
--

INSERT INTO `keys` (`keyid`, `email`, `keyvalue`) VALUES
(5, 'vibhaj8@gmail.com', 'b6f346ef8c7836054e6e74a4eceb4a8d');

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

CREATE TABLE IF NOT EXISTS `members` (
  `chainkeyid` bigint(20) NOT NULL AUTO_INCREMENT,
  `chainid` bigint(20) NOT NULL,
  `keyid` bigint(20) NOT NULL,
  PRIMARY KEY (`chainkeyid`),
  UNIQUE KEY `chainid_keyid` (`chainid`,`keyid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `members`
--


-- --------------------------------------------------------

--
-- Table structure for table `notes`
--

CREATE TABLE IF NOT EXISTS `notes` (
  `noteid` bigint(20) NOT NULL,
  `owner` bigint(20) NOT NULL,
  `title` varchar(255) NOT NULL,
  `note` mediumtext NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`noteid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notes`
--


-- --------------------------------------------------------

--
-- Table structure for table `proceedings`
--

CREATE TABLE IF NOT EXISTS `proceedings` (
  `procid` bigint(20) NOT NULL,
  `owner` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `year` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `eligibility` decimal(5,2) NOT NULL,
  `margin` decimal(5,2) NOT NULL,
  `max` int(11) NOT NULL,
  `deadline` datetime NOT NULL,
  PRIMARY KEY (`procid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proceedings`
--


-- --------------------------------------------------------

--
-- Table structure for table `resources`
--

CREATE TABLE IF NOT EXISTS `resources` (
  `rsrcid` bigint(20) NOT NULL AUTO_INCREMENT,
  `rsrcname` varchar(255) NOT NULL,
  `resource` text NOT NULL,
  PRIMARY KEY (`rsrcid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT AUTO_INCREMENT=1 ;

--
-- Dumping data for table `resources`
--


-- --------------------------------------------------------

--
-- Table structure for table `selections`
--

CREATE TABLE IF NOT EXISTS `selections` (
  `selid` bigint(20) NOT NULL,
  `eventid` bigint(20) NOT NULL,
  `owner` bigint(20) NOT NULL,
  `stageid` bigint(20) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`selid`),
  UNIQUE KEY `eventid_owner` (`eventid`,`owner`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `selections`
--


-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE IF NOT EXISTS `sessions` (
  `sessionid` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `expiry` datetime NOT NULL,
  PRIMARY KEY (`sessionid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sessions`
--


-- --------------------------------------------------------

--
-- Table structure for table `stages`
--

CREATE TABLE IF NOT EXISTS `stages` (
  `stageid` bigint(20) NOT NULL,
  `stage` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime NOT NULL,
  `open` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`stageid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stages`
--


-- --------------------------------------------------------

--
-- Table structure for table `storages`
--

CREATE TABLE IF NOT EXISTS `storages` (
  `stgid` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner` bigint(20) NOT NULL,
  `stgname` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `mime` varchar(255) NOT NULL,
  `size` bigint(20) NOT NULL,
  PRIMARY KEY (`stgid`),
  UNIQUE KEY `filepath_filename` (`filepath`,`filename`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `storages`
--


-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE IF NOT EXISTS `students` (
  `stuid` bigint(20) NOT NULL,
  `owner` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `rollno` varchar(255) NOT NULL,
  `course` varchar(255) NOT NULL,
  `year` int(11) NOT NULL,
  `cgpa` decimal(5,2) NOT NULL,
  `interests` varchar(255) NOT NULL DEFAULT '',
  `resume` bigint(20) NOT NULL,
  `photo` bigint(20) NOT NULL,
  `home` bigint(20) NOT NULL,
  `sgpa1` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa2` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa3` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa4` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa5` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa6` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa7` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa8` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa9` decimal(5,2) NOT NULL DEFAULT '0.00',
  `sgpa10` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ygpa1` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ygpa2` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ygpa3` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ygpa4` decimal(5,2) NOT NULL DEFAULT '0.00',
  `ygpa5` decimal(5,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`stuid`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--


-- --------------------------------------------------------

--
-- Table structure for table `webs`
--

CREATE TABLE IF NOT EXISTS `webs` (
  `webid` bigint(20) NOT NULL AUTO_INCREMENT,
  `parent` bigint(20) NOT NULL,
  `child` bigint(20) NOT NULL,
  `path` varchar(255) NOT NULL DEFAULT '/',
  `leaf` varchar(255) NOT NULL,
  PRIMARY KEY (`webid`),
  UNIQUE KEY `parent_path_leaf` (`parent`,`path`,`leaf`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `webs`
--

